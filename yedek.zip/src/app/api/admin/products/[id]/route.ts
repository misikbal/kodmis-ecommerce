import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import connectDB from '@/lib/mongodb';
import Product from '@/lib/models/Product';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const product = await Product.findById(params.id)
      .populate('categoryId', 'name')
      .populate('brandId', 'name')
      .lean();

    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    return NextResponse.json(product);
  } catch (error) {
    console.error('Error fetching product:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { 
      name, 
      description, 
      content, 
      type, 
      status, 
      price, 
      comparePrice, 
      costPrice, 
      sku, 
      trackQuantity, 
      quantity, 
      lowStockAlert, 
      weight, 
      dimensions, 
      downloadUrl, 
      downloadLimit, 
      images, 
      categoryId, 
      brandId, 
      hasVariants, 
      variants, 
      seoTitle, 
      seoDescription, 
      seoKeywords, 
      tags, 
      isFeatured, 
      isBestseller, 
      isNew 
    } = body;

    if (!name || !price) {
      return NextResponse.json({ error: 'Name and price are required' }, { status: 400 });
    }

    await connectDB();

    // Generate slug from name
    const slug = name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const product = await Product.findByIdAndUpdate(
      params.id,
      {
        name,
        slug,
        description,
        content,
        type: type || 'PHYSICAL',
        status: status || 'DRAFT',
        price,
        comparePrice,
        costPrice,
        sku,
        trackQuantity: trackQuantity !== false,
        quantity: quantity || 0,
        lowStockAlert: lowStockAlert || 5,
        weight,
        dimensions,
        downloadUrl,
        downloadLimit,
        images: images || [],
        categoryId: categoryId || null,
        brandId: brandId || null,
        hasVariants: hasVariants || false,
        variants: variants || [],
        seoTitle,
        seoDescription,
        seoKeywords,
        tags: tags || [],
        isFeatured: isFeatured || false,
        isBestseller: isBestseller || false,
        isNew: isNew || false,
      },
      { new: true, runValidators: true }
    );

    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    return NextResponse.json(product);
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const product = await Product.findByIdAndDelete(params.id);

    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
