'use client';

import { useState, useRef, useEffect } from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  List, 
  ListOrdered, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  Heading1,
  Heading2,
  Quote,
  Code,
  Image as ImageIcon,
  Upload,
  X,
  Search,
  Check
} from 'lucide-react';

interface CloudinaryImage {
  id: string;
  url: string;
  thumbnail: string;
  alt: string;
  created_at: string;
}

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export default function RichTextEditor({ 
  value, 
  onChange, 
  placeholder = "İçeriğinizi yazın...",
  className = ""
}: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [cloudinaryImages, setCloudinaryImages] = useState<CloudinaryImage[]>([]);
  const [isLoadingImages, setIsLoadingImages] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Editor içeriğini güncelle
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  // Formatting fonksiyonları
  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    handleContentChange();
  };

  const handleContentChange = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  // Fotoğraf yükleme
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    console.log('Uploading file:', file.name, file.size, file.type);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      console.log('Upload response:', data);
      
      if (data.success) {
        insertImage(data.url, file.name.split('.')[0]);
        loadCloudinaryImages(); // Listeyi yenile
      } else {
        console.error('Upload failed:', data.error);
      }
    } catch (error) {
      console.error('Fotoğraf yükleme hatası:', error);
    }
  };

  // Fotoğraf ekleme
  const insertImage = (url: string, alt: string) => {
    const imageHtml = `
      <div style="margin: 20px 0; text-align: center;">
        <img 
          src="${url}" 
          alt="${alt}" 
          style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);"
        />
      </div>
    `;
    
    if (editorRef.current) {
      editorRef.current.innerHTML += imageHtml;
      handleContentChange();
    }
  };

  // Cloudinary fotoğraflarını yükle
  const loadCloudinaryImages = async () => {
    setIsLoadingImages(true);
    try {
      const response = await fetch('/api/cloudinary/images?max_results=100');
      const data = await response.json();
      
      if (data.success) {
        console.log('Cloudinary images loaded:', data.images.length, data.images.slice(0, 2));
        setCloudinaryImages(data.images);
      } else {
        console.error('Fotoğraflar yüklenemedi:', data.error);
      }
    } catch (error) {
      console.error('Fotoğraf yükleme hatası:', error);
    } finally {
      setIsLoadingImages(false);
    }
  };

  // Fotoğraf seçimi
  const handleImageSelect = (imageUrl: string) => {
    if (selectedImages.includes(imageUrl)) {
      setSelectedImages(prev => prev.filter(url => url !== imageUrl));
    } else {
      setSelectedImages(prev => [...prev, imageUrl]);
    }
  };

  // Seçilen fotoğrafları ekle
  const addSelectedImages = () => {
    selectedImages.forEach(url => {
      insertImage(url, 'Fotoğraf');
    });
    
    setSelectedImages([]);
    setIsImageModalOpen(false);
  };

  return (
    <div className={`border border-gray-300 rounded-lg ${className}`}>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-1 p-2 border-b border-gray-200 bg-gray-100">
        {/* Text Formatting */}
        <div className="flex items-center gap-1 pr-2 border-r border-gray-300">
          <button
            onClick={() => execCommand('bold')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Kalın"
          >
            <Bold className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('italic')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="İtalik"
          >
            <Italic className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('underline')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Altı Çizili"
          >
            <Underline className="h-4 w-4" />
          </button>
        </div>

        {/* Lists */}
        <div className="flex items-center gap-1 pr-2 border-r border-gray-300">
          <button
            onClick={() => execCommand('insertUnorderedList')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Madde İşareti"
          >
            <List className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('insertOrderedList')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Numaralı Liste"
          >
            <ListOrdered className="h-4 w-4" />
          </button>
        </div>

        {/* Alignment */}
        <div className="flex items-center gap-1 pr-2 border-r border-gray-300">
          <button
            onClick={() => execCommand('justifyLeft')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Sola Hizala"
          >
            <AlignLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('justifyCenter')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Ortala"
          >
            <AlignCenter className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('justifyRight')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Sağa Hizala"
          >
            <AlignRight className="h-4 w-4" />
          </button>
        </div>

        {/* Headings */}
        <div className="flex items-center gap-1 pr-2 border-r border-gray-300">
          <button
            onClick={() => execCommand('formatBlock', 'h1')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Başlık 1"
          >
            <Heading1 className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('formatBlock', 'h2')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Başlık 2"
          >
            <Heading2 className="h-4 w-4" />
          </button>
        </div>

        {/* Special Blocks */}
        <div className="flex items-center gap-1 pr-2 border-r border-gray-300">
          <button
            onClick={() => execCommand('formatBlock', 'blockquote')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Alıntı"
          >
            <Quote className="h-4 w-4" />
          </button>
          <button
            onClick={() => execCommand('formatBlock', 'pre')}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Kod Bloğu"
          >
            <Code className="h-4 w-4" />
          </button>
        </div>

        {/* Images */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Fotoğraf Yükle"
          >
            <Upload className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              loadCloudinaryImages();
              setIsImageModalOpen(true);
            }}
            className="p-2 hover:bg-gray-300 rounded text-gray-700"
            title="Galeriden Seç"
          >
            <ImageIcon className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        className="min-h-96 p-4 focus:outline-none bg-white text-gray-900"
        style={{ outline: 'none' }}
        onInput={handleContentChange}
        dangerouslySetInnerHTML={{ __html: value }}
        data-placeholder={placeholder}
      />

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />

      {/* Image Selection Modal */}
      {isImageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Fotoğraf Seç</h3>
              <button
                onClick={() => setIsImageModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Fotoğraf ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Images Grid */}
            <div className="max-h-96 overflow-y-auto mb-4">
              {isLoadingImages ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-4">
                  {cloudinaryImages
                    .filter(image => 
                      image.alt.toLowerCase().includes(searchTerm.toLowerCase())
                    )
                    .map((image) => (
                      <div
                        key={image.id}
                        className={`relative cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${
                          selectedImages.includes(image.url)
                            ? 'border-blue-500 ring-2 ring-blue-200'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handleImageSelect(image.url)}
                      >
                        <img
                          src={image.thumbnail}
                          alt={image.alt}
                          className="w-full h-24 object-cover"
                        />
                        {selectedImages.includes(image.url) && (
                          <div className="absolute top-2 right-2 bg-blue-500 text-white rounded-full p-1">
                            <Check className="w-3 h-3" />
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 truncate">
                          {image.alt}
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setIsImageModalOpen(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                İptal
              </button>
              <button
                onClick={addSelectedImages}
                disabled={selectedImages.length === 0}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Seçilenleri Ekle ({selectedImages.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSS for placeholder */}
      <style jsx>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #6b7280;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
}
