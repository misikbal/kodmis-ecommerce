export interface Marketplace {
  id: string;
  name: string;
  slug: string;
  logo: string;
  website: string;
  isActive: boolean;
  isConnected: boolean;
  lastSyncDate?: string;
  syncStatus: 'SUCCESS' | 'ERROR' | 'PENDING' | 'DISABLED';
  errorCount: number;
  productCount: number;
  orderCount: number;
  totalSales: number;
  commissionRate: number;
  apiKey?: string;
  apiSecret?: string;
  webhookUrl?: string;
  settings: MarketplaceSettings;
  categories: MarketplaceCategory[];
  attributes: MarketplaceAttribute[];
  createdAt: string;
  updatedAt: string;
}

export interface MarketplaceSettings {
  autoSync: boolean;
  syncInterval: number; // minutes
  priceMarkup: number; // percentage
  stockSync: boolean;
  orderSync: boolean;
  imageSync: boolean;
}

export interface MarketplaceCategory {
  id: string;
  name: string;
  marketplaceCategoryId: string;
  isMapped: boolean;
}

export interface MarketplaceAttribute {
  id: string;
  name: string;
  marketplaceAttributeId: string;
  isMapped: boolean;
}

export interface SyncLog {
  id: string;
  marketplaceId: string;
  marketplaceName: string;
  type: 'PRODUCT' | 'ORDER' | 'STOCK' | 'PRICE';
  status: 'SUCCESS' | 'ERROR' | 'PENDING';
  itemsProcessed: number;
  itemsSuccessful: number;
  itemsFailed: number;
  errorMessage?: string;
  startedAt: string;
  completedAt?: string;
  duration?: number; // seconds
}

export interface MarketplaceStats {
  totalMarketplaces: number;
  activeMarketplaces: number;
  totalProducts: number;
  totalOrders: number;
  totalSales: number;
  syncErrors: number;
  lastSyncDate: string;
  marketplaces: Marketplace[];
  recentSyncLogs: SyncLog[];
}

export interface MarketplaceOrder {
  id: string;
  marketplaceId: string;
  marketplaceName: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  products: MarketplaceOrderProduct[];
  totalAmount: number;
  status: 'PENDING' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
  shippingAddress: MarketplaceAddress;
  billingAddress: MarketplaceAddress;
  createdAt: string;
  updatedAt: string;
}

export interface MarketplaceOrderProduct {
  id: string;
  productId: string;
  name: string;
  sku: string;
  quantity: number;
  price: number;
  totalPrice: number;
  imageUrl?: string;
}

export interface MarketplaceAddress {
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export interface MarketplaceProduct {
  id: string;
  name: string;
  sku: string;
  price: number;
  stock: number;
  category: string;
  status: 'ACTIVE' | 'INACTIVE' | 'SYNCED' | 'PENDING' | 'ERROR';
  marketplaceStatus: 'NOT_SYNCED' | 'SYNCED' | 'PENDING' | 'ERROR';
  marketplaceId?: string;
  marketplaceProductId?: string;
  lastSyncDate?: string;
  syncError?: string;
  images: string[];
  attributes: Record<string, any>;
}

export interface MarketplaceSyncStatus {
  marketplaceId: string;
  isRunning: boolean;
  lastSync: string;
  nextSync: string;
  progress: number;
}

export interface MarketplaceConnection {
  marketplaceId: string;
  name: string;
  apiKey: string;
  apiSecret: string;
  webhookUrl?: string;
  storeName?: string;
  sellerId?: string;
  isConnected: boolean;
  connectionTested: boolean;
  lastTestDate?: string;
  testResult?: 'SUCCESS' | 'ERROR';
  testErrorMessage?: string;
}
