import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import connectDB from '@/lib/mongodb';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    // Mock user data
    const users = [
      {
        id: '1',
        name: 'Ahmet Yılmaz',
        email: 'ahmet.yilmaz@kodmis.com',
        role: 'ADMIN',
        status: 'ACTIVE',
        lastLogin: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        twoFactorEnabled: true,
        permissions: ['READ_ALL', 'WRITE_ALL', 'DELETE_ALL'],
        createdAt: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '2',
        name: 'Ayşe Demir',
        email: 'ayse.demir@kodmis.com',
        role: 'MANAGER',
        status: 'ACTIVE',
        lastLogin: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        twoFactorEnabled: true,
        permissions: ['READ_ORDERS', 'WRITE_ORDERS'],
        createdAt: new Date(Date.now() - 200 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '3',
        name: 'Mehmet Kaya',
        email: 'mehmet.kaya@kodmis.com',
        role: 'OPERATOR',
        status: 'ACTIVE',
        lastLogin: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        twoFactorEnabled: false,
        permissions: ['READ_ORDERS', 'WRITE_ORDERS'],
        createdAt: new Date(Date.now() - 150 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];

    const roles = [
      {
        id: '1',
        name: 'Admin',
        description: 'Tam sistem erişimi',
        permissions: ['READ_ALL', 'WRITE_ALL', 'DELETE_ALL'],
        userCount: 1,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Manager',
        description: 'Yönetici yetkisi',
        permissions: ['READ_ORDERS', 'WRITE_ORDERS'],
        userCount: 1,
        createdAt: new Date().toISOString()
      }
    ];

    const auditLogs = [
      {
        id: '1',
        userId: '1',
        userName: 'Ahmet Yılmaz',
        action: 'LOGIN',
        resource: 'SYSTEM',
        ipAddress: '192.168.1.100',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        status: 'SUCCESS'
      }
    ];

    const stats = {
      totalUsers: users.length,
      activeUsers: users.filter(u => u.status === 'ACTIVE').length,
      inactiveUsers: 0,
      suspendedUsers: 0,
      pendingUsers: 0,
      totalRoles: roles.length,
      twoFactorEnabled: users.filter(u => u.twoFactorEnabled).length,
      recentLogins: 3,
      users,
      roles,
      auditLogs,
      recentActivity: [
        {
          user: 'Ahmet Yılmaz',
          action: 'Sistem ayarlarını güncelledi',
          timestamp: new Date().toISOString(),
          status: 'SUCCESS'
        }
      ],
      loginStats: [
        { date: '2024-12-01', logins: 45, uniqueUsers: 12 }
      ],
      permissionStats: [
        { permission: 'READ_ORDERS', userCount: 3, percentage: 100 }
      ]
    };

    return NextResponse.json({
      stats,
      totalPages: 1,
      currentPage: page,
      limit
    });
  } catch (error) {
    console.error('Error fetching user data:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    console.log('Creating user:', body);
    
    return NextResponse.json({ 
      success: true, 
      message: 'User created successfully' 
    });
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}