import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import connectDB from '@/lib/mongodb';
import User from '@/lib/models/User';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search');
    const status = searchParams.get('status');
    const tier = searchParams.get('tier');
    const segment = searchParams.get('segment');

    // Mock data for customers
    const customers = [
      {
        id: '1',
        firstName: 'Ahmet',
        lastName: 'Yılmaz',
        email: 'ahmet.yilmaz@email.com',
        phone: '+90 532 123 45 67',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        status: 'ACTIVE',
        tier: 'GOLD',
        totalOrders: 15,
        totalSpent: 8500,
        averageOrderValue: 567,
        lastOrderDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        registrationDate: new Date('2023-06-15').toISOString(),
        tags: ['VIP', 'Elektronik'],
        notes: 'Elektronik ürünlere ilgi duyuyor',
        address: {
          city: 'İstanbul',
          country: 'Türkiye'
        },
        lifetimeValue: 12000,
        customerSegment: 'Yüksek Değerli',
        isEmailVerified: true,
        isPhoneVerified: true,
        preferredLanguage: 'tr',
        lastLoginDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '2',
        firstName: 'Ayşe',
        lastName: 'Demir',
        email: 'ayse.demir@email.com',
        phone: '+90 533 234 56 78',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
        status: 'ACTIVE',
        tier: 'PLATINUM',
        totalOrders: 28,
        totalSpent: 15600,
        averageOrderValue: 557,
        lastOrderDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        registrationDate: new Date('2023-03-20').toISOString(),
        tags: ['Premium', 'Moda'],
        notes: 'Moda ve aksesuar ürünlerini tercih ediyor',
        address: {
          city: 'Ankara',
          country: 'Türkiye'
        },
        lifetimeValue: 18500,
        customerSegment: 'Premium',
        isEmailVerified: true,
        isPhoneVerified: true,
        preferredLanguage: 'tr',
        lastLoginDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '3',
        firstName: 'Mehmet',
        lastName: 'Kaya',
        email: 'mehmet.kaya@email.com',
        phone: '+90 534 345 67 89',
        status: 'ACTIVE',
        tier: 'SILVER',
        totalOrders: 8,
        totalSpent: 3200,
        averageOrderValue: 400,
        lastOrderDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        registrationDate: new Date('2023-08-10').toISOString(),
        tags: ['Spor'],
        address: {
          city: 'İzmir',
          country: 'Türkiye'
        },
        lifetimeValue: 4500,
        customerSegment: 'Orta Değerli',
        isEmailVerified: true,
        isPhoneVerified: false,
        preferredLanguage: 'tr',
        lastLoginDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '4',
        firstName: 'Fatma',
        lastName: 'Özkan',
        email: 'fatma.ozkan@email.com',
        phone: '+90 535 456 78 90',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
        status: 'ACTIVE',
        tier: 'BRONZE',
        totalOrders: 3,
        totalSpent: 850,
        averageOrderValue: 283,
        lastOrderDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        registrationDate: new Date('2023-11-05').toISOString(),
        tags: ['Yeni'],
        address: {
          city: 'Bursa',
          country: 'Türkiye'
        },
        lifetimeValue: 1200,
        customerSegment: 'Yeni Müşteri',
        isEmailVerified: true,
        isPhoneVerified: true,
        preferredLanguage: 'tr',
        lastLoginDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '5',
        firstName: 'Ali',
        lastName: 'Şahin',
        email: 'ali.sahin@email.com',
        phone: '+90 536 567 89 01',
        status: 'INACTIVE',
        tier: 'BRONZE',
        totalOrders: 1,
        totalSpent: 250,
        averageOrderValue: 250,
        lastOrderDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
        registrationDate: new Date('2023-12-01').toISOString(),
        tags: ['Pasif'],
        address: {
          city: 'Antalya',
          country: 'Türkiye'
        },
        lifetimeValue: 350,
        customerSegment: 'Düşük Değerli',
        isEmailVerified: false,
        isPhoneVerified: false,
        preferredLanguage: 'tr',
        lastLoginDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];

    // Mock customer segments
    const segments = [
      {
        id: '1',
        name: 'Premium Müşteriler',
        description: 'Yüksek harcama yapan, sadık müşteriler',
        criteria: 'LTV > 10000 TL, Son 6 ayda sipariş',
        customerCount: 45,
        averageLTV: 18500,
        isActive: true,
        createdAt: new Date('2024-01-01').toISOString()
      },
      {
        id: '2',
        name: 'Yüksek Değerli',
        description: 'Orta-yüksek harcama yapan müşteriler',
        criteria: 'LTV 5000-10000 TL arası',
        customerCount: 120,
        averageLTV: 7500,
        isActive: true,
        createdAt: new Date('2024-01-02').toISOString()
      },
      {
        id: '3',
        name: 'Orta Değerli',
        description: 'Orta seviye harcama yapan müşteriler',
        criteria: 'LTV 2000-5000 TL arası',
        customerCount: 280,
        averageLTV: 3500,
        isActive: true,
        createdAt: new Date('2024-01-03').toISOString()
      },
      {
        id: '4',
        name: 'Yeni Müşteriler',
        description: 'Son 3 ayda kayıt olan müşteriler',
        criteria: 'Kayıt tarihi son 3 ay',
        customerCount: 150,
        averageLTV: 1200,
        isActive: true,
        createdAt: new Date('2024-01-04').toISOString()
      },
      {
        id: '5',
        name: 'Risk Altındaki Müşteriler',
        description: 'Son 6 ayda sipariş vermeyen müşteriler',
        criteria: 'Son sipariş 6+ ay önce',
        customerCount: 85,
        averageLTV: 2800,
        isActive: true,
        createdAt: new Date('2024-01-05').toISOString()
      }
    ];

    // Calculate stats
    const totalCustomers = customers.length;
    const activeCustomers = customers.filter(c => c.status === 'ACTIVE').length;
    const newCustomersThisMonth = customers.filter(c => {
      const regDate = new Date(c.registrationDate);
      const now = new Date();
      return regDate.getMonth() === now.getMonth() && regDate.getFullYear() === now.getFullYear();
    }).length;
    const averageLTV = customers.reduce((sum, c) => sum + c.lifetimeValue, 0) / customers.length;

    // Get top spenders
    const topSpenders = [...customers]
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 6);

    // Get recent customers
    const recentCustomers = [...customers]
      .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime())
      .slice(0, 5);

    // Apply filters
    let filteredCustomers = customers;
    
    if (search) {
      filteredCustomers = filteredCustomers.filter(customer =>
        customer.firstName.toLowerCase().includes(search.toLowerCase()) ||
        customer.lastName.toLowerCase().includes(search.toLowerCase()) ||
        customer.email.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    if (status) {
      filteredCustomers = filteredCustomers.filter(customer => customer.status === status);
    }
    
    if (tier) {
      filteredCustomers = filteredCustomers.filter(customer => customer.tier === tier);
    }
    
    if (segment) {
      filteredCustomers = filteredCustomers.filter(customer => customer.customerSegment === segment);
    }

    // Pagination
    const totalPages = Math.ceil(filteredCustomers.length / limit);
    const startIndex = (page - 1) * limit;
    const paginatedCustomers = filteredCustomers.slice(startIndex, startIndex + limit);

    const stats = {
      totalCustomers,
      activeCustomers,
      newCustomersThisMonth,
      averageLTV,
      topSpenders,
      recentCustomers,
      segments
    };

    return NextResponse.json({
      customers: paginatedCustomers,
      stats,
      totalPages,
      currentPage: page,
      limit
    });
  } catch (error) {
    console.error('Error fetching customer data:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const body = await request.json();
    
    // Create new customer
    console.log('Creating customer:', body);
    
    return NextResponse.json({ 
      success: true, 
      message: 'Customer created successfully' 
    });
  } catch (error) {
    console.error('Error creating customer:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const body = await request.json();
    
    // Update customer
    console.log('Updating customer:', body);
    
    return NextResponse.json({ 
      success: true, 
      message: 'Customer updated successfully' 
    });
  } catch (error) {
    console.error('Error updating customer:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'Customer ID is required' }, { status: 400 });
    }
    
    // Delete customer
    console.log('Deleting customer:', id);
    
    return NextResponse.json({ 
      success: true, 
      message: 'Customer deleted successfully' 
    });
  } catch (error) {
    console.error('Error deleting customer:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
